#!/bin/sh

#  makeDocs.sh
#
#
#  Created by PARKER Martin on 08/05/2019.
#   This is a script to quickly make 4 different output files with pandoc from a range of .md files.
############# usage ##############
# cd directory/with/yourFinalProjectFiles/
# bash utils/makeDocs.sh outputFileName
# this will make you .html, .pdf, .docx & an ebook in epub format called outputfileName, change this argument for whatever file name you like.

outputName=$1
# bit of error catching here, test if the structure/docStructure.md file exists, if not, then make one from the .md files in your directory. You should re-order the list of files to your own requirements by editing the docstructure.md file.

if [ ! -d "structure" ] ; then mkdir structure; fi
if [ ! -f "structure/docStructure.md" ]; then ls *.md >> structure/docStructure.md; fi

# docX make a word document from your structure
pandoc `cat structure/docStructure.md` --toc --filter pandoc-citeproc --standalone  --mathjax -o $outputName.docx

# html
pandoc `cat structure/docStructure.md`  --filter pandoc-citeproc --toc -s --metadata --mathjax -f markdown -t html5 -o $outputName.html

# ebook
pandoc `cat structure/docStructure.md`  --toc --filter pandoc-citeproc --standalone --pdf-engine=xelatex --mathjax -o $outputName.epub

# pdf - the one you're going to submit
pandoc styling/pdfStyle.yaml `cat structure/docStructure.md` --filter pandoc-citeproc --standalone --pdf-engine=xelatex -o $outputName.pdf

open $outputName.pdf
