---
# this file sets many typesetting preferences for your document output, it also controls some things relating to the way the infrastructure of the document behaves when ported to HTML, pdf and other formats. The list of settings starts with the document-specific things and works its way down to less-important matters relating to the look and feel of the document such as line spacing and font choice.

# About your project
title: My title
subtitle: |
  Submitted in accordance with the requirements for the degree of
  - MSc Sound Design
  - Reid School of Music
  - Edinburgh College of Art
  - University of Edinburgh
author: Your NAME
abstract: |  
  An overview of your project, what's been achieved and what can we look forward to

keywords: [markdown, pandoc, academic writing, final projects, typesetting for artists]
subject: Exploring a way to make writing multifaceted documents more straightforward for students and staff.
thanks: not required unless you want to have something here on the first page, but thanks a lot Internet, you were very helpful.
# about you
email: your@email
affiliation: University of Edinburgh
date: \today

# data and style information relating to the document
bibliography: "/Users/huwenqian/Desktop/Learn/Summer_Project/Bibliography/My Library.bib"
csl: styling/journal-of-new-music-research.csl
css: styling/pandoc.css # from here, https://gist.github.com/killercup/5917178

# setup the look and feel of the pdf version of the document:
documentclass: scrartcl # a latex specific setting that makes the PDF behave
papersize: a4 # change when you want it in US legal etc.
linestretch: 1.2  # set your line spacing preferences
fontsize: 12pt
mainfont: "Palatino"
sansfont: "Helvetica"
monofont: "Andale Mono"
titlefont: "Times"
geometry: "left=4cm, right=3cm, top=2.5cm, bottom=2.5cm"

# table of contents and other behaviours in your PDF and elsewhere.
toc: true
toc-depth: 2
toc-title: "Table of Contents"
lof: true
lot: true
link-citations: true
---
